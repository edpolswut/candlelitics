import React, { useState, useEffect, useMemo } from 'react';
import Chart from 'react-apexcharts';

// 1. Adicionamos a prop onMetadataLoaded aqui
const Graph = ({ Name = 'PETR4', config = {}, onMetadataLoaded }) => {
  const chartType = config.chartType || 'candlestick';
  
  const [series, setSeries] = useState([{ name: 'Preço', data: [] }]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currency, setCurrency] = useState('BRL');
  
  // Esses estados locais (logoUrl, stockName) deixaram de ser estritamente necessários 
  // para renderização aqui dentro, mas mantivemos para manter a sua lógica intacta.
  const [logoUrl, setLogoUrl] = useState(null);
  const [stockName, setStockName] = useState(Name);
  
  const API_KEY = 'ie2zCfzxZAY3SysfiKnZM9';

  // Fetch de dados da Brapi API
  useEffect(() => {
    const fetchStockData = async () => {
      try {
        setLoading(true);
        
        // Adicionar .SA se não tiver (para ações brasileiras)
        const stockCode = Name.includes('.') ? Name : `${Name}.SA`;
        const url = `https://brapi.dev/api/quote/${stockCode}?token=${API_KEY}`;
        console.log('Fazendo fetch para:', url);
        
        const response = await fetch(url);
        
        if (!response.ok) {
          throw new Error(`Erro na API: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Resposta da API:', data);
        
        if (data.results && data.results[0]) {
          const stock = data.results[0];
          const currentPrice = stock.regularMarketPrice;
          
          // Salvar currency e logo localmente (opcional agora)
          setCurrency(stock.currency || 'BRL');
          setLogoUrl(stock.logourl);
          setStockName(stock.longName || Name);
          
          // 2. AQUI ENVIAMOS OS DADOS PARA O CARD PAI!
          if (onMetadataLoaded) {
            onMetadataLoaded({
              name: stock.longName || stock.shortName || Name,
              logo: stock.logourl
            });
          }
          
          // Gerar dados históricos simulados das últimas 2 semanas baseado no preço atual
          const chartData = [];
          const today = new Date();
          today.setHours(0, 0, 0, 0); // Reset para meia-noite
          
          for (let i = 13; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            
            // Simular variação aleatória ao redor do preço atual
            const variation = (Math.random() - 0.5) * 10;
            const open = currentPrice + variation;
            const close = currentPrice + (Math.random() - 0.5) * 10;
            const high = Math.max(open, close) + Math.random() * 3;
            const low = Math.min(open, close) - Math.random() * 3;
            
            chartData.push({
              x: date.getTime(),
              y: [
                parseFloat(open.toFixed(2)),
                parseFloat(high.toFixed(2)),
                parseFloat(low.toFixed(2)),
                parseFloat(close.toFixed(2))
              ]
            });
          }
          
          console.log('Chart data gerado:', chartData);
          setSeries([{ name: 'Preço', data: chartData }]);
          setError(null);
        } else {
          throw new Error('Resposta da API inválida');
        }
      } catch (err) {
        setError(err.message);
        console.error('Erro ao buscar dados:', err);
      } finally {
        setLoading(false);
      }
    };

    if (Name) {
      fetchStockData();
    }
  }, [Name, onMetadataLoaded]); // Adicionamos onMetadataLoaded às dependências do useEffect

  // Cores padrões fixas
  const UP_COLOR = '#00b746';
  const DOWN_COLOR = '#ef403c';

  // Configurações dinâmicas baseadas no tipo de gráfico
  const getChartOptions = () => {
    const baseOptions = {
      chart: {
        type: chartType,
        height: 'auto',
        width: '100%',
        toolbar: {
          show: true,
          tools: {
            download: true,
            selection: true,
            zoom: true,
            zoomin: true,
            zoomout: true,
            pan: true,
            reset: true
          }
        },
        zoom: {
          enabled: true,
          type: 'xy'
        }
      },
      // 3. O BLOCO DE TITLE FOI TOTALMENTE REMOVIDO DAQUI
      xaxis: {
        type: 'datetime',
        tickPlacement: 'on',
        axisBorder: {
          show: true,
          color: '#ddd'
        },
        axisTicks: {
          show: true,
          color: '#ddd'
        },
        labels: {
          format: 'dd MMM',
          style: {
            colors: '#666'
          },
          datetimeFormatter: {
            year: 'yyyy',
            month: 'MMM',
            day: 'dd',
            hour: 'HH:mm'
          }
        }
      },
      yaxis: {
        title: {
          text: `Preço (${currency})`,
          style: {
            color: '#2c3e50'
          }
        },
        labels: {
          style: {
            colors: '#666'
          }
        },
        tooltip: {
          enabled: true
        }
      },
      plotOptions: {
        candlestick: {
          colors: {
            upward: UP_COLOR,
            downward: DOWN_COLOR
          }
        },
        line: {
          colors: [UP_COLOR]
        },
        area: {
          colors: [UP_COLOR]
        },
        bar: {
          colors: [UP_COLOR]
        }
      },
      grid: {
        show: true,
        borderColor: '#e8ecf1',
        xaxis: {
          lines: {
            show: true,
            color: '#e8ecf1'
          }
        },
        yaxis: {
          lines: {
            show: true,
            color: '#e8ecf1'
          }
        }
      },
      stroke: {
        colors: [UP_COLOR]
      },
      fill: {
        colors: [UP_COLOR],
        opacity: 0.3
      },
      states: {
        hover: {
          filter: {
            type: 'none'
          }
        }
      }
    };

    return baseOptions;
  };

  const options = useMemo(() => getChartOptions(), [chartType, currency]); // Removido 'Name' das dependências pois não é mais usado no gráfico

  return (
    <div className="graph-container" style={{ height: '100%', width: '100%' }}>
      {loading && <p style={{ textAlign: 'center' }}>Carregando dados...</p>}
      {error && <p style={{ textAlign: 'center', color: 'red' }}>Erro: {error}</p>}
      
      {!loading && !error && (
        <Chart 
          options={options} 
          series={series} 
          type={chartType} 
          height="100%" 
          width="100%" 
        />
      )}
    </div>
  );
};

export default Graph;