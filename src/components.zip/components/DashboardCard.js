import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { FaExpandArrowsAlt, FaCompressArrowsAlt, FaTrash, FaSearch } from 'react-icons/fa';
import Graph from './Graph';
import './DashboardCard.css';

const CardHeader = ({ 
  ticker, 
  setTicker, 
  companyMetadata, 
  onDelete, 
  onToggleFullscreen, 
  isFullscreen 
}) => {
  const [isSearching, setIsSearching] = useState(false);
  const [tempTicker, setTempTicker] = useState(ticker);

  const handleSubmit = (e) => {
    e.preventDefault();
    setTicker(tempTicker.toUpperCase());
    setIsSearching(false);
  };

  return (
    <div className="card-header drag-handle">
      <div className="card-info-group">
        {/* SVG/Logo retornado da API via Graph */}
        {companyMetadata?.logo ? (
          <img src={companyMetadata.logo} alt="logo" className="company-logo-svg" />
        ) : (
          <div className="company-logo-placeholder" />
        )}
        
        {!isSearching ? (
          <div className="company-details" onClick={() => setIsSearching(true)}>
            <span className="ticker-badge">{ticker}</span>
            <span className="company-name-text">{companyMetadata?.name || "Carregando..."}</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="header-search-form">
            <input 
              autoFocus
              className="header-search-input"
              value={tempTicker}
              onChange={(e) => setTempTicker(e.target.value)}
              onBlur={() => setIsSearching(false)}
            />
          </form>
        )}
      </div>
      
      <div className="card-actions">
        <button onClick={() => setIsSearching(!isSearching)} className="action-btn">
          <FaSearch />
        </button>
        <button onClick={onToggleFullscreen} className="action-btn">
          {isFullscreen ? <FaCompressArrowsAlt /> : <FaExpandArrowsAlt />}
        </button>
        <button onClick={onDelete} className="action-btn delete-btn">
          <FaTrash />
        </button>
      </div>
    </div>
  );
};

function DashboardCard({ id, widgetConfig }) {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [ticker, setTicker] = useState(widgetConfig.ativos[0]);
  const [metadata, setMetadata] = useState({ name: '', logo: '' });

  const cardContent = (
    <div className="dashboard-card-wrapper">
      <CardHeader 
        ticker={ticker}
        setTicker={setTicker}
        companyMetadata={metadata}
        onDelete={() => console.log("Delete", id)}
        onToggleFullscreen={() => setIsFullscreen(!isFullscreen)}
        isFullscreen={isFullscreen}
      />
      <div className="card-body">
        <Graph 
          Name={ticker} 
          config={{ chartType: widgetConfig.tipo_grafico }} 
          onMetadataLoaded={setMetadata} // Callback para passar nome/logo para o header
        />
      </div>
    </div>
  );

  if (!isFullscreen) return cardContent;

  return (
    <>
      <div className="dashboard-card-wrapper ghost-card"></div>
      {createPortal(
        <div className="fullscreen-overlay">{cardContent}</div>,
        document.body
      )}
    </>
  );
}

export default DashboardCard;